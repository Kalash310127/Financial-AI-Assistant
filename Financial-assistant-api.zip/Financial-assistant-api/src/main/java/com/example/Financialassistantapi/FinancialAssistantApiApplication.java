package com.example.Financialassistantapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinancialAssistantApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinancialAssistantApiApplication.class, args);
	}

}
